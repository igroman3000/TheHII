using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Collections.Generic;

namespace TrueExeIconMouseShooter
{
    public class Program : Form
    {
        private int score = 0;
        private bool isGameOver = false;
        private bool isGameStarted = false;
        
        // Храним координаты летающих врагов (квадратиков)
        private List<Rectangle> enemies = new List<Rectangle>();
        
        private Timer gameTimer;
        private Random random = new Random();

        // Размеры синей игровой панели
        private Rectangle bluePanelRect = new Rectangle(40, 50, 300, 180);

        public Program()
        {
            // Окно в виде чистой иконки без рамок Windows
            this.Size = new Size(390, 460);
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.Lime;
            this.TransparencyKey = Color.Lime;
            this.DoubleBuffered = true;

            // Настройка игрового таймера для движения врагов
            gameTimer = new Timer();
            gameTimer.Interval = 40; 
            gameTimer.Tick += GameLoop;
            gameTimer.Start();

            // Обработка кликов мыши (стрельба) и клавиатуры
            this.MouseClick += Program_MouseClick;
            this.KeyDown += Program_KeyDown;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // 1. БЕЛЫЙ ЛИСТ (Тело иконки со срезанным уголком)
            int width = 370;
            int height = 430;
            int cornerSize = 40;

            Point[] iconPoints = new Point[]
            {
                new Point(10, 10),
                new Point(width - cornerSize, 10),
                new Point(width, cornerSize),
                new Point(width, height),
                new Point(10, height)
            };

            g.FillPolygon(Brushes.White, iconPoints);
            g.DrawPolygon(new Pen(Color.FromArgb(130, 135, 144), 3), iconPoints);

            Point[] foldPoints = new Point[]
            {
                new Point(width - cornerSize, 10),
                new Point(width - cornerSize, cornerSize),
                new Point(width, cornerSize)
            };
            g.FillPolygon(Brushes.White, foldPoints);
            g.DrawPolygon(new Pen(Color.FromArgb(130, 135, 144), 2), foldPoints);

            // 2. СИНЯЯ ПАНЕЛЬ
            g.FillRectangle(Brushes.DarkBlue, bluePanelRect);
            g.DrawRectangle(new Pen(Color.FromArgb(0, 100, 200), 2), bluePanelRect);

            // Ограничиваем отрисовку игры только внутри синей панели
            Region oldRegion = g.Clip;
            g.Clip = new Region(bluePanelRect);

            // 3. ОТРИСОВКА ИГРЫ ВНУТРИ СИНЕЙ ПАНЕЛИ
            if (!isGameStarted)
            {
                Font fontStart = new Font("Arial", 11, FontStyle.Bold);
                g.DrawString("Кликни по синей панели,\n чтобы запустить шутер!", fontStart, Brushes.White, bluePanelRect.X + 45, bluePanelRect.Y + 70);
            }
            else if (!isGameOver)
            {
                // Рисуем врагов (оранжевые квадратики-корабли, как в твоем коде)
                foreach (var enemy in enemies)
                {
                    g.FillRectangle(Brushes.Orange, enemy);
                    g.DrawRectangle(Pens.White, enemy);
                }
            }
            else
            {
                Font fontGameOver = new Font("Arial", 16, FontStyle.Bold);
                g.DrawString("GAME OVER", fontGameOver, Brushes.Red, bluePanelRect.X + 75, bluePanelRect.Y + 60);
                g.DrawString("Нажми R для рестарта", new Font("Arial", 10), Brushes.White, bluePanelRect.X + 75, bluePanelRect.Y + 100);
            }

            // Возвращаем обычную область отрисовки
            g.Clip = oldRegion;

            // 4. НАДПИСИ И ФИГНИ ПОД ПАНЕЛЬЮ
            g.DrawString("SCORE: " + score, new Font("Lucida Console", 14, FontStyle.Bold), Brushes.DimGray, 40, 250);

            g.FillRectangle(Brushes.LightGray, 40, 290, 290, 12);
            g.FillRectangle(Brushes.LightGray, 40, 315, 220, 12);
            g.FillRectangle(Brushes.LightGray, 40, 340, 260, 12);

            g.DrawString("[ Стрельба: Клик мыши ]      [ Выход - Esc ]", new Font("Arial", 9), Brushes.Silver, 55, 400);
        }

        private void GameLoop(object sender, EventArgs e)
        {
            if (!isGameStarted || isGameOver) return;

            // Шанс появления нового врага сверху синей панели
            if (random.Next(0, 100) < 4 && enemies.Count < 5)
            {
                int enemyWidth = 25;
                int startX = random.Next(bluePanelRect.X + 5, bluePanelRect.X + bluePanelRect.Width - enemyWidth - 5);
                enemies.Add(new Rectangle(startX, bluePanelRect.Y - enemyWidth, enemyWidth, enemyWidth));
            }

            // Движение врагов сверху вниз
            for (int i = enemies.Count - 1; i >= 0; i--)
            {
                Rectangle rect = enemies[i];
                rect.Y += 3; // Скорость падения квадратов

                // Если пропустил врага и он упал за нижний край синей панели — конец игры
                if (rect.Y > bluePanelRect.Y + bluePanelRect.Height)
                {
                    isGameOver = true;
                    break;
                }

                enemies[i] = rect;
            }

            this.Invalidate(); // Перерисовка иконки
        }

        private void Program_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                // Старт игры по первому клику на синюю панель
                if (!isGameStarted)
                {
                    if (bluePanelRect.Contains(e.Location))
                    {
                        isGameStarted = true;
                        score = 0;
                        enemies.Clear();
                        this.Invalidate();
                    }
                    return;
                }

                if (isGameOver) return;

                // СТРЕЛЬБА КЛИКОМ: Проверяем, попал ли клик мыши по какому-либо врагу
                for (int i = enemies.Count - 1; i >= 0; i--)
                {
                    // Точно такое же условие Contains(e.Location), как в твоем коде!
                    if (enemies[i].Contains(e.Location))
                    {
                        enemies.RemoveAt(i); // Уничтожаем врага при попадании
                        score += 10;         // Начисляем очки
                        this.Invalidate();
                        return; // Выходим, чтобы один клик убивал только одного врага
                    }
                }
            }
        }

        private void Program_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Application.Exit();

            // Рестарт игры на кнопку R
            if (isGameOver && e.KeyCode == Keys.R)
            {
                isGameOver = false;
                score = 0;
                enemies.Clear();
                this.Invalidate();
            }
        }

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Program());
        }
    }
}